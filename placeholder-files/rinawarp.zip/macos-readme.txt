This is a placeholder for RinaWarp Terminal macOS universal binary. Real binary coming soon!
