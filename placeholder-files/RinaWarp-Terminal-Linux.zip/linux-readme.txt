This is a placeholder for RinaWarp Terminal Linux AppImage. Real binary coming soon!
